module Project2 {
	requires org.junit.jupiter.api;
	requires junit;
}