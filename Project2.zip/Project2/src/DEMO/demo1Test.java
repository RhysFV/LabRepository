package DEMO;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import squareNo.Square1;

class demo1Test {

	@Test
	public void test() {
		demo1 s1 = new demo1();
		int ans = s1.calSq(20);
		assertEquals(400,ans);
	}

}
