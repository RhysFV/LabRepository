package Concatenate;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class joinStringTest {

	private static final String bat = null;
	private static final String man = null;
	private static final Object batman = null;

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test() {
		joinString s1 = new joinString();
		String A = s1.joinString(bat, man);
		assertEquals(batman, A);
		
	}

}
