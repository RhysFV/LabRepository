package CUBE;

public class cube1 {
	
	public int calCube(int num) {
		return num * num * num;
	}

}
