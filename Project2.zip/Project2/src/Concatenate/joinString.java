package Concatenate;
import java.util.Scanner;

public class joinString {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter 2 words: ");
		String a = scanner.nextLine();
		String b = scanner.nextLine();
		String c = a + b;
		System.out.println("Concatenated word is "+ c +".");
		
		scanner.close();
		

	}

	public String joinString(String bat, String man) {
		// TODO Auto-generated method stub
		return null;
	}

}
