package Area;

public class rectangle {
	int l = 10;
	int b = 12;
	
	public int area(int i, int j) {
		return l * b;
		}
	
	public int perimeter(int i, int j) {
		return 2 * (l + b);
	}
}
