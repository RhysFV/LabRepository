package Area;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class rectangleTest {
	
	@Test
	void test() {
		fail("Not yet implemented");
		rectangle r = new rectangle();
		int ans = r.area(10, 12);
		assertEquals(120, ans);
	}
		
		@Test
		void test1() {
			fail("Not yet implemented");
			rectangle r = new rectangle();
			int ans = r.perimeter(10, 12);
			assertEquals(44, ans);
			}

}
