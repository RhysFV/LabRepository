package CUBE;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class cube1Test {

	@Test
	void test() {
		cube1 s1 = new cube1();
		int ans = s1.calCube(2);
		assertEquals(8, ans);
	}
	
	@Test
	void test1() {
		cube1 s1 = new cube1();
		int ans = s1.calCube(20);
		assertEquals(80, ans);
	}
	
	@Test
	void test2() {
		cube1 s1 = new cube1();
		int ans = s1.calCube(-2);
		assertEquals(-8, ans);
	}
	
	

}
