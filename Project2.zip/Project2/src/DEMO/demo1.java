package DEMO;

public class demo1 {
	public int calSq(int num)
	{
		return num * num;
	}

}
