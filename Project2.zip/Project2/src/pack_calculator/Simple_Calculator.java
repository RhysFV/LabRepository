package pack_calculator;
import java.util.Scanner;

public class Simple_Calculator {
	
	public void AddNos() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 numbers: ");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int result1 = num1 + num2;
		}
	
	public void SubNos() {
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter 2 numbers: ");
		int num3 = sc1.nextInt();
		int num4 = sc1.nextInt();
		int result2 = num3 + num4;
	}

}
